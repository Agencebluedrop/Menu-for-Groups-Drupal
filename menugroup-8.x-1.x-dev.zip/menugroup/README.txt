"Menu for groups" 
